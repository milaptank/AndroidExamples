package com.wmtcore.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

import com.wmtcore.util.Debug;

public class DoubleTapImageView extends ImageView implements View.OnTouchListener {
    private Context context;
    private GestureListener mGestureListener;
    private GestureDetector mGestureDetector;

    public DoubleTapImageView(Context context) {
        super(context);
        sharedConstructing(context);
    }

    public DoubleTapImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        sharedConstructing(context);
    }

    public DoubleTapImageView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        sharedConstructing(context);
    }


    private void sharedConstructing(Context context) {
        super.setClickable(true);
        this.context = context;
        mGestureListener = new GestureListener();
        Debug.e("Adding", "Listener:::");
        mGestureDetector = new GestureDetector(context, mGestureListener, null, true);
        setOnTouchListener(this);
    }

    /**
     * Called when a touch event is dispatched to a view. This allows listeners to
     * get a chance to respond before the target view.
     *
     * @param v     The view the touch event has been dispatched to.
     * @param event The MotionEvent object containing full information about
     *              the event.
     * @return True if the listener has consumed the event, false otherwise.
     */
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        invalidate();
        return true;
    }

    public class GestureListener extends GestureDetector.SimpleOnGestureListener {

        @Override
        public boolean onDoubleTap(MotionEvent e) {

            Debug.e("onDoubleTap", "onDoubleTap");
            return true;
        }
    }

}