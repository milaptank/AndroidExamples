package com.wmt.view;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.tappple.followersplus.R;
import com.tappple.followersplus.activity.BaseActivity;
import com.tappple.followersplus.fragment.BaseFragment;
import com.tappple.followersplus.utils.Constant;

public class FPWebViewFragment extends BaseFragment {
    View view;
    WebView webview;
    private ProgressBar progressBar;
    private BaseActivity baseActivity;

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment EngagementFragment.
     */
    public static FPWebViewFragment newInstance() {
        FPWebViewFragment fragment;
        fragment = new FPWebViewFragment();
        Bundle args = new Bundle();
        args.putInt(Constant.WHAT_FRAGMENT, Constant.FragmentType.FRAGMENT_WEBVIEW);
        fragment.setArguments(args);
        return fragment;
    }

    private void initActivityHandling() {
        baseActivity = (BaseActivity) getActivity();
        baseActivity.setBackIcon(true);
        baseActivity.setSelectedFragment(this);
        baseActivity.setTitle(getString(R.string.tv_followers_plus));
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initActivityHandling();
        String url = "http://tappple.com";

        Bundle bundle = getArguments();
        if (bundle != null) {
            baseActivity.setTitle(bundle.getString("title"));
            url = bundle.getString("url");
        }
        WebSettings webSettings = webview.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setSupportZoom(true);
        webSettings.setBuiltInZoomControls(true);
        webview.loadUrl(url);
        webview.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });
        webview.setWebChromeClient(new WebChromeClient() {

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (progressBar.getVisibility() == View.GONE)
                    progressBar.setVisibility(View.VISIBLE);
                progressBar.setProgress(newProgress);
                if (newProgress == 100)
                    progressBar.setVisibility(View.GONE);
                super.onProgressChanged(view, newProgress);
            }

        });


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_fp_webview, container, false);
        progressBar = (ProgressBar) view.findViewById(R.id.pbhWebView);
        webview = (WebView) view.findViewById(R.id.wvFpWebView);
        return view;
    }


    /**
     * Will be used as handle to save transactions in backstack
     *
     * @return tag text
     */
    @Override
    public String getTagText() {
        return null;
    }

    /**
     * To enable fragments capture back-press event and utilize it before
     * it's used in the hosting Activity.
     *
     * @return true if consumed, else false
     */
    @Override
    public boolean onBackPressed() {
        return false;
    }
}
