package com.wmtcore.listener;

import android.view.View;

public interface OnRVItemClickListener {
    void onItemClick(View v, int position);
}
