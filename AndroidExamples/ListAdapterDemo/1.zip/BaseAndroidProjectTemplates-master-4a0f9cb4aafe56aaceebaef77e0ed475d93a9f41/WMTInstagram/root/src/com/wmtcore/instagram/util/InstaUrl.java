package com.wmtcore.instagram.util;

import android.text.TextUtils;

import okhttp3.HttpUrl;

public class InstaUrl {

    public static class AuthBuilder {

        HttpUrl.Builder urlBuilder;

        public AuthBuilder() {
            urlBuilder = HttpUrl.parse(InstaUtils.getAuthURL()).newBuilder();
        }

        public AuthBuilder setClientId() {
            urlBuilder.addQueryParameter(InstaConstant.KEY_CLIENT_ID, InstaUtils.getClientId());
            return this;
        }

        public AuthBuilder setClientSecret() {
            urlBuilder.addQueryParameter(InstaConstant.KEY_CLIENT_SECRET, InstaUtils.getClientSecret());
            return this;
        }

        public AuthBuilder setDisplayTouch() {
            urlBuilder.addQueryParameter(InstaConstant.KEY_DISPLAY, "touch");
            return this;
        }

        public AuthBuilder setRedirectUri() {
            urlBuilder.addQueryParameter(InstaConstant.KEY_REDIRECT_URI, InstaUtils.getRedirectURL());
            return this;
        }

        public AuthBuilder setResponseType(String responseType) {
            urlBuilder.addQueryParameter(InstaConstant.KEY_RESPONSE_TYPE, responseType);
            return this;
        }

        public AuthBuilder setScope(String scope) {
            urlBuilder.addEncodedQueryParameter(InstaConstant.KEY_SCOPE, scope);
            return this;
        }

        public String getUrl() {
            return urlBuilder.build().toString();
        }
    }

    public static class APIBuilder {

        HttpUrl.Builder urlBuilder;

        public APIBuilder() {
            urlBuilder = HttpUrl.parse(InstaUtils.getAPIURL()).newBuilder();
        }

        public APIBuilder users() {
            urlBuilder.addPathSegment(InstaConstant.KEY_ENDPOINT_USERS);
            return this;
        }

        public APIBuilder self() {
            urlBuilder.addPathSegment(InstaConstant.KEY_SELF);
            return this;
        }

        public APIBuilder setId(String id) {
            urlBuilder.addPathSegment(TextUtils.isEmpty(id) ? "self" : id);
            return this;
        }

        public APIBuilder media() {
            urlBuilder.addPathSegment(InstaConstant.KEY_ENDPOINT_MEDIA);
            return this;
        }

        public APIBuilder recent() {
            urlBuilder.addPathSegment(InstaConstant.KEY_ENDPOINT_RECENT);
            return this;
        }

        public APIBuilder liked() {
            urlBuilder.addPathSegment(InstaConstant.KEY_ENDPOINT_LIKED);
            return this;
        }

        public APIBuilder follows() {
            urlBuilder.addPathSegment(InstaConstant.KEY_ENDPOINT_FOLLOWS);
            return this;
        }

        public APIBuilder followedBy() {
            urlBuilder.addPathSegment(InstaConstant.KEY_ENDPOINT_FOLLOWED_BY);
            return this;
        }

        public APIBuilder requestedBy() {
            urlBuilder.addPathSegment(InstaConstant.KEY_ENDPOINT_REQUESTED_BY);
            return this;
        }

        public APIBuilder relationship() {
            urlBuilder.addPathSegment(InstaConstant.KEY_ENDPOINT_RELATIONSHIP);
            return this;
        }

        public APIBuilder shortCode() {
            urlBuilder.addPathSegment(InstaConstant.KEY_ENDPOINT_SHORTCODE);
            return this;
        }

        public APIBuilder search() {
            urlBuilder.addPathSegment(InstaConstant.KEY_ENDPOINT_SEARCH);
            return this;
        }

        public APIBuilder comments() {
            urlBuilder.addPathSegment(InstaConstant.KEY_ENDPOINT_COMMENTS);
            return this;
        }

        public APIBuilder likes() {
            urlBuilder.addPathSegment(InstaConstant.KEY_ENDPOINT_LIKES);
            return this;
        }

        public APIBuilder tags() {
            urlBuilder.addPathSegment(InstaConstant.KEY_ENDPOINT_TAGS);
            return this;
        }

        public APIBuilder setTags(String tags) {
            urlBuilder.addPathSegment(tags);
            return this;
        }

        public APIBuilder locations() {
            urlBuilder.addPathSegment(InstaConstant.KEY_ENDPOINT_LOCATIONS);
            return this;
        }

        public APIBuilder setSearchQuery(String query) {
            urlBuilder.addQueryParameter(InstaConstant.KEY_ENDPOINT_QUERY, query);
            return this;
        }

        public APIBuilder accessToken() {
            urlBuilder.addQueryParameter(InstaConstant.KEY_ACCESS_TOKEN, InstaUtils.getInstaAccessToken());
            return this;
        }

        public APIBuilder setMinId(String minId) {
            urlBuilder.addQueryParameter(InstaConstant.KEY_ENDPOINT_MIN_ID, minId);
            return this;
        }

        public APIBuilder setMaxId(String maxId) {
            urlBuilder.addQueryParameter(InstaConstant.KEY_ENDPOINT_MAX_ID, maxId);
            return this;
        }

        public APIBuilder setCount() {
            urlBuilder.addQueryParameter(InstaConstant.KEY_ENDPOINT_COUNT, String.valueOf(InstaConstant.MAX_COUNT));
            return this;
        }

        public APIBuilder setCount(int count) {
            urlBuilder.addQueryParameter(InstaConstant.KEY_ENDPOINT_COUNT, String.valueOf(count));
            return this;
        }

        public APIBuilder setMaxLikeId(String id) {
            urlBuilder.addQueryParameter(InstaConstant.KEY_ENDPOINT_MAX_LIKE_ID, id);
            return this;
        }

        public APIBuilder setLat(String lat) {
            urlBuilder.addQueryParameter(InstaConstant.KEY_ENDPOINT_LAT, lat);
            return this;
        }

        public APIBuilder setLng(String lng) {
            urlBuilder.addQueryParameter(InstaConstant.KEY_ENDPOINT_LNG, lng);
            return this;
        }

        public APIBuilder setDistance(String distance) {
            urlBuilder.addQueryParameter(InstaConstant.KEY_ENDPOINT_DISTANCE, distance);
            return this;
        }

        public APIBuilder setMinTagId(String minTagId) {
            urlBuilder.addQueryParameter(InstaConstant.KEY_ENDPOINT_MIN_TAG_ID, minTagId);
            return this;
        }

        public APIBuilder setMaxTagId(String maxTagId) {
            urlBuilder.addQueryParameter(InstaConstant.KEY_ENDPOINT_MAX_TAG_ID, maxTagId);
            return this;
        }

        public APIBuilder setFacebookPlacesId(String facebookPlacesId) {
            urlBuilder.addQueryParameter(InstaConstant.KEY_ENDPOINT_FACEBOOK_PLACES_ID, facebookPlacesId);
            return this;
        }

        public String getUrl() {
            return urlBuilder.build().toString();
        }
    }
}
