package com.wmtcore.instagram.listener;

public interface InstagramLoginListener {

    void onLoginSuccess(String code);

    void onLoginError(int errorCode, String description);
}
