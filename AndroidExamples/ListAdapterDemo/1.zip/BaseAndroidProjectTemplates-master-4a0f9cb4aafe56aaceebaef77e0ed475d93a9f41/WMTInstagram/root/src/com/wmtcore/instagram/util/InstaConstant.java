package com.wmtcore.instagram.util;


public class InstaConstant {

    public static final String KEY_URI_PARAM_CODE = "code";
    public static final String KEY_URI_PARAM_TOKEN = "token";
    public static final String KEY_CLIENT_ID = "client_id";
    public static final String KEY_CLIENT_SECRET = "client_secret";
    public static final String KEY_REDIRECT_URI = "redirect_uri";
    public static final String KEY_RESPONSE_TYPE = "response_type";
    public static final String KEY_SCOPE = "scope";
    public static final String KEY_GRANT_TYPE = "grant_type";
    public static final String KEY_URI_PARAM_AUTHORIZATION_CODE = "authorization_code";
    public static final String KEY_ACCESS_TOKEN = "access_token";
    public static final String KEY_DISPLAY = "display";
    public static final String KEY_ENDPOINT_USERS = "users";
    public static final String KEY_ENDPOINT_MEDIA = "media";
    public static final String KEY_ENDPOINT_RECENT = "recent";
    public static final String KEY_ENDPOINT_LIKED = "liked";
    public static final String KEY_ENDPOINT_SEARCH = "search";
    public static final String KEY_ENDPOINT_QUERY = "q";
    public static final String KEY_ENDPOINT_FOLLOWS = "follows";
    public static final String KEY_ENDPOINT_FOLLOWED_BY = "followed-by";
    public static final String KEY_ENDPOINT_REQUESTED_BY = "requested-by";
    public static final String KEY_ENDPOINT_RELATIONSHIP = "relationship";
    public static final String KEY_ENDPOINT_SHORTCODE = "shortcode";
    public static final String KEY_ENDPOINT_COMMENTS = "comments";
    public static final String KEY_ENDPOINT_LIKES = "likes";
    public static final String KEY_ENDPOINT_TAGS = "tags";
    public static final String KEY_ENDPOINT_LOCATIONS = "locations";
    public static final String KEY_ENDPOINT_MIN_ID = "min_id";
    public static final String KEY_ENDPOINT_MAX_ID = "max_id";
    public static final String KEY_ENDPOINT_COUNT = "count";
    public static final String KEY_ENDPOINT_MAX_LIKE_ID = "id";
    public static final String KEY_ENDPOINT_ACTION = "action";
    public static final String KEY_ENDPOINT_TEXT = "text";
    public static final String KEY_ENDPOINT_LAT = "lat";
    public static final String KEY_ENDPOINT_LNG = "lng";
    public static final String KEY_ENDPOINT_DISTANCE = "distance";
    public static final String KEY_ENDPOINT_MIN_TAG_ID = "min_tag_id";
    public static final String KEY_ENDPOINT_MAX_TAG_ID = "max_tag_id";
    public static final String KEY_ENDPOINT_FACEBOOK_PLACES_ID = "facebook_places_id";
    public static final String KEY_SELF = "self";

    public static final long SYNC_NORMAL_DIFF = 300; //Normal Sync diff
    public static final long SYNC_DETAILS_DIFF = 43200; //Details Sync diff
    public static final int REQ_RATE_LIMIT = 60; //Like and Relationship request in particular req time
    public static final int REQ_RATE_LIMIT_AT_ONE_TIME = 20; //Relationship request at a time
    public static final int REQ_RATE_LIMIT_DURATION_MINUTE = 60; //Like and Relationship request time in minute
    public static final int COUNT_BLOCKED_USERS = 15; //Like and Relationship request time in minute

    //Media Type
    public static final String KEY_MEDIA_IMAGE = "image";
    public static final String KEY_MEDIA_VIDEO = "video";

    //Count for fetching the records from API
    public static final int MAX_COUNT = 500;

    //Http Response Code
    public static final String HTTP_CODE_200 = "200";
    public static final String HTTP_CODE_400 = "400";
    public static final String HTTP_CODE_500 = "500";

    //Relation Constant
    public static final String REL_OUT_FOLLOWS = "follows";
    public static final String REL_OUT_REQUESTED = "requested";
    public static final String REL_NONE = "none";
    public static final String REL_IN_FOLLOWED_BY = "followed_by";
    public static final String REL_IN_REQUESTED_BY = "requested_by";
    public static final String REL_IN_BLOCKED_BY_YOU = "blocked_by_you";

    //Status
    public static final int STATUS_0 = 0;
    public static final int STATUS_1 = 1;
    public static final int STATUS_2 = 2;

    //Response JSON Keys
    public static final String RESPONSE_META = "meta";
    public static final String RESPONSE_CODE = "code";
    public static final String RESPONSE_ERROR_TYPE = "error_type";
    public static final String RESPONSE_DATA = "data";
    public static final String RESPONSE_NEXT_URL = "next_url";
    public static final String RESPONSE_PAGINATION = "pagination";

    //Blocked USER Status
    public static final String USER_STATUS_BLOCKED = "1";
    public static final String USER_STATUS_UNBLOCKED = "0";

    //RequestType
    public static final int REQ_LIKE = 1;
    public static final int REQ_RELATIONSHIP = 2;

    //SyncType
    public static final int SYNC_NORMAL = 1;
    public static final int SYNC_DETAIL = 2;

    //DCL Type
    public static final String DCL_LIKE = "L";
    public static final String DCL_COMMENT = "C";

    //DCL LIKE COMMENT MAX COUNT
    public static final int MAX_LIKE_COUNT = 120;
    public static final int MAX_COMMENT_COUNT = 101;


    public static class PrefKeys {
        public static final String PK_INSTA_ACCESS_TOKEN = "access_token";
        public static final String PK_INSTA_USERNAME = "username";
        public static final String PK_INSTA_PROFILE_PIC = "profile_picture";
        public static final String PK_INSTA_FULLNAME = "full_name";
        public static final String PK_INSTA_ID = "id";
        public static final String PK_INSTA_FOLLOWED_BY = "followed_by";
        public static final String PK_INSTA_FOLLOWS = "follows";
        public static final String PK_INSTA_MEDIA = "media";
        public static final String PK_AUTO_SYNC_IN_HOME = "auto_sync_in_home";
        public static final String PK_TICKER_ARRAY = "ticker_array";
        public static final String PK_SYNC_HISTORY_ID = "sync_id";
    }

}