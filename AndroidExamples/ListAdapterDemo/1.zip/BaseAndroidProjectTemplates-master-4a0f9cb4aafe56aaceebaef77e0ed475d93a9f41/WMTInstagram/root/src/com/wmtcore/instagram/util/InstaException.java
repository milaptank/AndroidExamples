package com.wmtcore.instagram.util;

public class InstaException {
    public static final String OAUTH_ACCESS_TOKEN = "OAuthAccessTokenException";
    public static final String API_NOT_ALLOWED = "APINotAllowedError";
    public static final String OAUTH_PERMISSION = "OAuthPermissionsException";
}